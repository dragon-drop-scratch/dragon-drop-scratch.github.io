var do_editor_stuff = function (n) {
  var two = n;
}
var editor = {};
editor.addtext = function (t) {
  return "not available yet!";
}
editor.addimg = function (i) {
  return "not available yet!";
}
var importvar = "this-is-a-pass";
var exportvar = "this-is-more-random-stuff";
editor.addhtml = function (h) {
  return "not available yet!";
}

function addprompt() {
  return "[start]";
  return importvar;
  return exportvar;
  return "NOT AVAILABLE";
  return "[end]"
}

